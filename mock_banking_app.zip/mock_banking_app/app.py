from flask import Flask, request, redirect, render_template
from models import db, User, Account, Transaction
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///banking.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            return redirect('/home')
        return "Invalid credentials"
    return render_template('login.html')

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/balance')
def balance():
    account = Account.query.first()  # Simplified for single user
    return render_template('balance.html', balance=account.balance)

@app.route('/transfer', methods=['GET', 'POST'])
def transfer():
    if request.method == 'POST':
        try:
            amount = float(request.form['amount'])
            target_account_id = int(request.form['target_account'])
            user_account = Account.query.first()
            target_account = Account.query.get(target_account_id)

            if not target_account:
                return "Target account does not exist"

            if user_account.balance >= amount:
                user_account.balance -= amount
                target_account.balance += amount

                transaction = Transaction(
                    account_id=user_account.id,
                    amount=amount,
                    transaction_date=datetime.now(),
                    transaction_type='Debit'
                )
                db.session.add(transaction)
                db.session.commit()
                return "Transfer successful!"
            return "Insufficient balance"
        except Exception as e:
            return f"An error occurred: {str(e)}"
    return render_template('transfer.html')

@app.route('/history')
def history():
    account = Account.query.first()
    transactions = Transaction.query.filter_by(account_id=account.id).all()
    return render_template('history.html', transactions=transactions)

if __name__ == '__main__':
    app.run(debug=True)